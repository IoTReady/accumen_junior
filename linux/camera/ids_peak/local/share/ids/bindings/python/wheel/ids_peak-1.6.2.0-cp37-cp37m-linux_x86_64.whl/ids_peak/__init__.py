

try:
    from . import ids_peak
except ImportError as previousError:
    err = ImportError(
        "Could not load the python extension module! Either the shared "
        "library \"ids_peak\" could not be found or the library "
        "version you are using is older than the bindings (expected "
        "v1."
        "6."
        "2."
        "0)"
    )
    err.name = previousError.name
    err.path = previousError.path
    raise err from None

