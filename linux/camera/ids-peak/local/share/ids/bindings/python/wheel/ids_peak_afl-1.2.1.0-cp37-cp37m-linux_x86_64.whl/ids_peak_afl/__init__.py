

try:
    from . import ids_peak_afl
except ImportError as previousError:
    err = ImportError(
        "Could not load the python extension module! Either one of the "
        "following shared libraries could not be found or one of the library "
        "versions you are using is older than the bindings:\n"
        "expected \"ids_peak_afl\" v1."
        "2."
        "1."
        "0\n"
        "expected \"ids_peak\" v1.6.2.0\n"
        "expected \"ids_peak_ipl\" v1.9.0.0"
    )
    err.name = previousError.name
    err.path = previousError.path
    raise err from None

